from typing import Any, Mapping
from django import forms
from django.core.files.base import File
from django.db.models.base import Model
from django.forms.utils import ErrorList
from .models import Company, Job

class JobForm(forms.ModelForm):
    # title = forms.CharField(widget=forms.TextInput(attrs={"class": "form-control"}))
    # description = forms.Textarea(attrs={"class": "form-control"})
    class Meta:
        model = Job
        fields=[
            'title',
            'description',
            'responsability',
            'qualification',
            'salaire',
            'nature',
            'author'
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['title'].label = "Write down here the name of the job"
        self.fields['description'].label = "Describe here the job"
        self.fields['responsability'].label = "Write here the responsability of the person in charge"
        self.fields['qualification'].label = "Enumerate here the qualifications you're looking for"
        self.fields['salaire'].label = "Approximate salary of the job"
        self.fields['nature'].label = "Type of the job"
        
class SignUpForm(forms.ModelForm):

    class Meta:
        model = Company
        fields = [
            'name',
            'adress',
            'year',
            'description',
            'pwd',
            'mail',
            'logo'
        ]
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
