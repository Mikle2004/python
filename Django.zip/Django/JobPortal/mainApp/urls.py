from django.urls import include, path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('home', views.index, name="index"),
    path('signIn', views.signIn, name="signIn"),
    path('signUp', views.signUp, name="signUp"),
    path('contact', views.contact, name="contact"),
    path('about', views.about, name="about"),
    path('category', views.category, name="category"),
    path('job-detail/<int:id>', views.job_detail, name="job_detail"),
    path('job_list', views.job_list, name="job_list"),
    path('testimonial', views.testimonial, name="testimonial"),
    path('404', views.notFound, name="not_found"),
    path('postAJob', views.postAJob, name="postAJob"),
    path('logout', views.logOut, name="logout"),
]