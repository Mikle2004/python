from django.shortcuts import render, redirect
from django.contrib.sessions.models import Session
from django.contrib.sessions.backends.db import SessionStore
from django.contrib.auth import logout, authenticate, login
from django.http import HttpResponse
from django.utils import timezone
from .models import Job, Company
from .forms import JobForm, SignUpForm
import requests

s = ""

def index(request):
    return render(request, 'index.html', {})

def signIn(request):
    if request.method == "POST":
        email = request.POST.get("mail")
        pwd = request.POST.get("pwd")
        user = Company.objects.all()


        for u in user:
            if u.mail == email and u.pwd == pwd:
                request.session['id'] = u.id
                request.session['email'] = u.mail
                request.session['pwd'] = u.pwd
                request.session['logo'] = u.logo.url
                
                return redirect('/job-portal/')
            else:
                return redirect('/job-portal/signIn')
    
    return render(request, 'login/signIn.html', {})

def signUp(request):
    context = {'form': SignUpForm}
    if request.method == "POST":
        form = SignUpForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()
            return redirect('/job-portal/signIn')
        else:
            return redirect('/job-portal/signUp')
        # name_company = request.POST.get("name")
        # email_company = request.POST.get("mail")
        # pwd_company = request.POST.get("pwd")
        # year_company = request.POST.get("year")
        # description_company = request.POST.get("description")
        # adress_company = request.POST.get("adress")
        # logo_company = request.POST.get("logo")

        # company = Company(name=name_company, adress=adress_company, year=year_company, description=description_company, pwd=pwd_company, mail=email_company, logo=logo_company)
        # company.save()


    return render(request, 'login/signUp.html', context)

def about(request):
    return render(request, 'about.html', {})

def job_detail(request, id):
    context = {
        'jobs': Job.objects.all().filter(id = id),
        'id': id
    }
    return render(request, 'job-detail.html', context)

def job_list(request):
    context = {
        'jobs': Job.objects.all(),
        'full_time_job': Job.objects.filter(nature='full_time'),
        'part_time_job': Job.objects.filter(nature='part_time')
    }
    return render(request, 'job-list.html', context)

def testimonial(request):
    return render(request, 'testimonial', {})

def category(request):
    return render(request, 'category.html', {})

def contact(request):
    return render(request, 'contact.html', {})

def testimonial(request):
    return render(request, 'testimonial.html', {})

def notFound(request):
    return render(request, '404.html', {})

def postAJob(request):

    if 'id' not in request.session:
        return redirect('/job-portal/signIn')
    else:
        context = {'form': JobForm}
        c = Company.objects.get(id=request.session['id'])
        
        if request.method == "POST":
            title_job = request.POST.get("title")
            description_job = request.POST.get("description")
            responsability_job = request.POST.get("responsability")
            qualification_job = request.POST.get("qualification")
            salaire_job = request.POST.get("salaire")
            nature_job = request.POST.get("nature")

            job = Job(title=title_job, description=description_job, responsability=responsability_job, qualification=qualification_job, salaire=salaire_job, nature=nature_job, author=c, caption=c.logo)
            job.save()

        return render(request, 'postAJob.html', context)

def logOut(request):

    logout(request)

    return redirect('/job-portal/')