from typing import Any
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
# Create your models here.

class Company(models.Model):
    name = models.CharField(max_length=100)
    adress = models.CharField(max_length=100)
    year = models.IntegerField()
    description = models.TextField(default='')
    pwd = models.CharField(default='', max_length=50)
    mail = models.CharField(max_length=200)
    logo = models.ImageField(default="", upload_to="media/img/%y")

    def __str(self):
        return self.name

class Job(models.Model):
    TYPE = (
    ('full_time', 'full_time'),
    ('part_time', 'part_time')
    )
    title = models.CharField(max_length=100)
    description = models.TextField()
    responsability = models.TextField()
    qualification = models.TextField()
    date_posted = models.DateTimeField(default=timezone.now)
    salaire = models.IntegerField(default=100)
    nature = models.CharField(max_length=50, default='full_time', choices=TYPE)
    author = models.ForeignKey(Company, on_delete=models.CASCADE)
    caption = models.ImageField(default="", upload_to="media/img/%y")

    def __str__(self):
        return self.title

    
class Client(models.Model):
    full_name = models.CharField(max_length=100)
    mail = models.CharField(max_length=100)
    age = models.IntegerField()
    adress = models.CharField(max_length=100)
    pwd = models.TextField(default="")
    def __str__(self):
        return self.full_name


